package com.cg.ibs.loanmgmt.services;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ibs.loanmgmt.models.LoanTypeBean;
import com.cg.ibs.loanmgmt.repositories.LoanTypeDao;
@Service
public class ApplyLoanServiceImpl implements ApplyLoanService {
	private static Logger LOGGER = Logger.getLogger(ApplyLoanServiceImpl.class);
@Autowired
	private LoanTypeDao loanTypeDao;
	
	@Override
	public LoanTypeBean getLoanTypeByTypeID(Integer typeId) {
		LOGGER.info("Fetching loan type details");
		return loanTypeDao.getLoanTypeByTypeID(typeId);
	}

}
