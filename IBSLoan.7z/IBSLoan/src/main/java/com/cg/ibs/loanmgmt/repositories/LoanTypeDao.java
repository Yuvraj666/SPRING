package com.cg.ibs.loanmgmt.repositories;

import com.cg.ibs.loanmgmt.models.LoanTypeBean;

public interface LoanTypeDao {
	public LoanTypeBean getLoanTypeByTypeID(Integer typeId);
	
}
