package com.cg.ibs.loanmgmt.services;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ibs.loanmgmt.models.BankAdmins;
import com.cg.ibs.loanmgmt.repositories.BankAdminsDao;

@Service
public class BankAdminServiceImpl implements BankAdminService {
	private static Logger LOGGER = Logger.getLogger(BankAdminServiceImpl.class);

	@Autowired
	private BankAdminsDao bankAdminsDao;
	@Override
	public boolean verifyBankLogin(String userId, String password) {
		LOGGER.info("Verifying customer login details");
		boolean login = false;
		BankAdmins admin = bankAdminsDao.getAdminByUserId(userId);
		if (null != admin && password.equals(admin.getPassword())) {
			login = true;
		}
		return login;
	}
	@Override
	public BankAdmins getBankAdmin(String userId) {
		return bankAdminsDao.getAdminByUserId(userId);
	}

}
