package com.cg.ibs.loanmgmt.repositories;

import java.util.List;

import com.cg.ibs.loanmgmt.models.AccountHolding;
import com.cg.ibs.loanmgmt.models.CustomerBean;

public interface AccountHoldingDao {
	public List<AccountHolding> getSavingAccountListByUci(CustomerBean customer);
}
