package com.cg.ibs.loanmgmt.services;

import com.cg.ibs.loanmgmt.models.LoanTypeBean;

public interface ApplyLoanService {
	LoanTypeBean getLoanTypeByTypeID(Integer typeId);
}
