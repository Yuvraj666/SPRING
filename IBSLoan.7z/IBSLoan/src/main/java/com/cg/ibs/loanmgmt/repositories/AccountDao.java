package com.cg.ibs.loanmgmt.repositories;

import java.math.BigInteger;

import com.cg.ibs.loanmgmt.models.Account;
import com.cg.ibs.loanmgmt.models.LoanMaster;

public interface AccountDao {
	Account getAccount(BigInteger accountNumber);

	Account addLoanAmount(LoanMaster loanMaster);
}
