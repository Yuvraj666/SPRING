package com.cg.ibs.loanmgmt.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.ibs.loanmgmt.models.CustomerBean;
import com.cg.ibs.loanmgmt.models.LoanTypeBean;
import com.cg.ibs.loanmgmt.services.ApplyLoanService;
import com.cg.ibs.loanmgmt.services.CustomerService;

@Controller
@Scope("session")
public class CustomerController {
	@Autowired
	private CustomerService customerService;
	@Autowired
	private ApplyLoanService applyLoanService;
	private LoanTypeBean loanTypeBean = new LoanTypeBean();
	CustomerBean loggedInCustomer = new CustomerBean();

	@RequestMapping("/applyLoan")
	public String applyLoan() {
		return "applyLoan";
	}

	@RequestMapping(method = RequestMethod.GET, value = "/customer")
	public ModelAndView loginRole(@RequestParam("userId") String userId) {
		ModelAndView modelAndView = new ModelAndView();
		loggedInCustomer = customerService.getCustomer(userId);
		modelAndView.addObject("loginVerified", "Welcome " + customerService.getCustomer(userId).getFirstName());
		modelAndView.setViewName("loggedinCustomerPage");
		return modelAndView;
	}

	@RequestMapping(value = "/addLoan", method = RequestMethod.GET)
	public String showNewDeptPage() {
		return "addLoan";
	}

	@RequestMapping(value = "/homeCalculateEMI")
	public ModelAndView getDetailsForHomeLoan() {
		Integer typeId= 1;
		loanTypeBean = applyLoanService.getLoanTypeByTypeID(typeId);
		
		return null;
	}
}
